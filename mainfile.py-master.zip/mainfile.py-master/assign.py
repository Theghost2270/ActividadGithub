from mainfile import Testarithmetic

Testarithmetic.test_addition()
Testarithmetic.cube_test()
Testarithmetic.multiplication_test()